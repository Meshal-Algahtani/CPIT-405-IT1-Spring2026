<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Country Explorer - Meshal Algahtani</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .search-row { display: flex; gap: 10px; margin-bottom: 16px; }
        .search-row input[type="text"] { flex-grow: 1; padding: 10px 14px; background-color: #2a2a2a; border: 1px solid #444; color: white; border-radius: 4px; font-size: 15px; }
        .search-row input[type="text"]:focus { outline: none; border-color: #38bdf8; }
        .search-row button { margin-top: 0; padding: 10px 22px; font-size: 15px; }
        #status-msg { color: #94a3b8; font-size: 14px; margin-bottom: 14px; min-height: 20px; }
        .countries-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 16px; }
        .country-card { background-color: #2a2a2a; border: 1px solid #333; border-radius: 8px; overflow: hidden; display: flex; flex-direction: column; align-items: center; padding-bottom: 14px; transition: border-color 0.2s; }
        .country-card:hover { border-color: #38bdf8; }
        .country-card img { width: 100%; height: 100px; object-fit: cover; border-bottom: 1px solid #444; }
        .country-info { padding: 10px 12px 0; width: 100%; }
        .country-name { color: #e0e0e0; font-weight: bold; font-size: 15px; margin-bottom: 8px; }
        .country-detail { display: flex; align-items: center; gap: 6px; font-size: 13px; color: #94a3b8; margin-bottom: 4px; }
        #loading { display: none; color: #38bdf8; font-size: 15px; margin-bottom: 10px; }
    </style>
</head>
<body>

<header>
    <div class="header-info">
        <h1>Meshal Mohammed Algahtani</h1>
        <p>IT Student | Cybersecurity</p>
    </div>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="labs.php">Labs</a></li>
            <li><a href="myworks.php" class="active">My Works</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
    </nav>
</header>

<div class="container">
    <aside class="sidebar">
        <div class="profile-card">
            <h3>About This App</h3>
            <hr>
            <p style="font-size:14px; color:#94a3b8; text-align:left;">Search and explore countries using the REST Countries API. Data is fetched live from restcountries.com</p>
            <br>
            <h3>Portfolio Links</h3>
            <hr>
            <p><a href="myworks.php">← My Works</a></p>
            <p><a href="app1.php">View App 1</a></p>
        </div>
    </aside>

    <main class="content">
        <section class="card">
            <h2>Country Explorer</h2>
            <div class="search-row">
                <input type="text" id="search-input" placeholder="Search for a country..." />
                <button id="search-btn">Search</button>
            </div>
            <div id="loading">Loading...</div>
            <p id="status-msg"></p>
            <div class="countries-grid" id="results"></div>
        </section>
    </main>
</div>

<footer>
    <p>&copy; 2026 Meshal Algahtani - CPIT 405 Portfolio</p>
</footer>

<script>
const searchInput = document.getElementById('search-input');
const searchBtn   = document.getElementById('search-btn');
const resultsDiv  = document.getElementById('results');
const statusMsg   = document.getElementById('status-msg');
const loading     = document.getElementById('loading');

function formatPopulation(num) {
    if (num >= 1_000_000) return (num / 1_000_000).toFixed(1) + 'M';
    if (num >= 1_000) return (num / 1_000).toFixed(0) + 'K';
    return num.toString();
}

async function searchCountries() {
    const query = searchInput.value.trim();
    if (!query) { statusMsg.textContent = 'Please enter a country name to search.'; resultsDiv.innerHTML = ''; return; }
    resultsDiv.innerHTML = '';
    statusMsg.textContent = '';
    loading.style.display = 'block';
    try {
        const response = await fetch(`https://restcountries.com/v3.1/name/${encodeURIComponent(query)}`);
        if (!response.ok) {
            statusMsg.textContent = response.status === 404 ? 'No countries found. Try a different name.' : 'Something went wrong. Please try again.';
            loading.style.display = 'none';
            return;
        }
        const countries = await response.json();
        loading.style.display = 'none';
        statusMsg.textContent = `${countries.length} result${countries.length !== 1 ? 's' : ''} found`;
        countries.forEach(country => {
            const name       = country.name.common;
            const flag       = country.flags?.svg || country.flags?.png || '';
            const capital    = country.capital ? country.capital[0] : 'N/A';
            const region     = country.region || 'N/A';
            const population = country.population ? formatPopulation(country.population) : 'N/A';
            const languages  = country.languages ? Object.values(country.languages).join(', ') : 'N/A';
            const card = document.createElement('div');
            card.className = 'country-card';
            card.innerHTML = `
                <img src="${flag}" alt="Flag of ${name}" />
                <div class="country-info">
                    <p class="country-name">${name}</p>
                    <div class="country-detail"><span>🏛</span>${capital}</div>
                    <div class="country-detail"><span>🌍</span>${region}</div>
                    <div class="country-detail"><span>👥</span>${population}</div>
                    <div class="country-detail"><span>🗣</span>${languages}</div>
                </div>`;
            resultsDiv.appendChild(card);
        });
    } catch (error) {
        loading.style.display = 'none';
        statusMsg.textContent = 'Network error. Please check your connection and try again.';
    }
}

searchBtn.addEventListener('click', searchCountries);
searchInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') searchCountries(); });
</script>

</body>
</html>
